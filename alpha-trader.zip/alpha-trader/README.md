# Alpha Trader — Paid Trading Signals App

A public, self-hosted web app for selling trading-signal subscriptions.
The owner controls everything from a private admin panel; subscribers pay a
joining fee and unlock the Crypto / Forex / Stocks / Updates sections with an
access code.

## Run locally

Requires Node.js 22+.

```bash
npm install
npm start
```

Open http://localhost:3000 — admin panel at `/admin/login` (default password `admin123`, change it in Settings immediately).

## Deploy

See `DEPLOY-GUIDE.md` (Roman Urdu step-by-step: GitHub + Render free hosting).

## How it works

- **Public pages:** `/` (signals feed, locked without a code), `/join` (fee + payment instructions + "I've paid" form), `/unlock` (enter access code).
- **Admin (`/admin`):** post/edit/delete signals with entry, stop loss, TP1–TP3, timeframe, notes and status (Active / TP1–TP3 Hit / SL Hit / Closed); post market updates; generate/revoke access codes; approve/reject payment requests (approval auto-generates a code to share with the subscriber); configure app name, fee, payment details, WhatsApp number, code validity and admin password.
- **Storage:** SQLite via Node's built-in `node:sqlite` (file `signals.db`, created on first run). No external database needed.
- **Auth:** admin session via signed cookie; subscriber access via signed cookie holding a validated, unexpired, non-revoked code.
