// Alpha Trader — paid trading signals app (Crypto / Forex / Stocks / Updates)
const express = require('express');
const cookieParser = require('cookie-parser');
const crypto = require('node:crypto');
const path = require('path');
const { db, getSetting, setSetting, hashPassword, verifyPassword } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.SESSION_SECRET || 'dev-secret-change-me';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser(SECRET));
app.use(express.static(path.join(__dirname, 'public')));

// ---------------- helpers ----------------
const now = () => Date.now();
const esc = (s) => String(s ?? '');
const MARKETS = ['crypto', 'forex', 'stocks'];
const STATUS_LABELS = { active: 'Active', tp1: 'TP1 Hit', tp2: 'TP2 Hit', tp3: 'TP3 Hit', sl: 'SL Hit', closed: 'Closed' };

function currentAccess(req) {
  const code = req.signedCookies.access;
  if (!code) return null;
  return db.prepare(
    `SELECT * FROM access_codes WHERE code = ? AND revoked = 0 AND (expires_at IS NULL OR expires_at > ?)`
  ).get(code, now()) || null;
}

function requireAdmin(req, res, next) {
  if (req.signedCookies.admin === '1') return next();
  res.redirect('/admin/login');
}

function makeCode() {
  const part = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `SGN-${part()}-${part()}`;
}

function fmtDate(ts) {
  return new Date(ts).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}
app.locals.fmtDate = fmtDate;
app.locals.STATUS_LABELS = STATUS_LABELS;

// ---------------- public pages ----------------
app.get('/', (req, res) => {
  const access = currentAccess(req);
  const signals = access ? db.prepare('SELECT * FROM signals ORDER BY created_at DESC').all() : [];
  const updates = access ? db.prepare('SELECT * FROM updates ORDER BY created_at DESC LIMIT 20').all() : [];
  res.render('index', {
    appName: getSetting('app_name', 'Alpha Trader'),
    fee: getSetting('fee_amount', '50'),
    currency: getSetting('fee_currency', 'USDT'),
    access, signals, updates,
    tab: MARKETS.includes(req.query.tab) || req.query.tab === 'updates' ? req.query.tab : 'crypto',
  });
});

app.get('/unlock', (req, res) => {
  res.render('unlock', { appName: getSetting('app_name', 'Alpha Trader'), error: null });
});

app.post('/unlock', (req, res) => {
  const code = esc(req.body.code).trim().toUpperCase();
  const row = db.prepare(
    'SELECT * FROM access_codes WHERE code = ? AND revoked = 0 AND (expires_at IS NULL OR expires_at > ?)'
  ).get(code, now());
  if (!row) {
    return res.render('unlock', { appName: getSetting('app_name', 'Alpha Trader'), error: 'Ghalat ya expire shuda code. Dobara check karein.' });
  }
  res.cookie('access', code, { signed: true, httpOnly: true, maxAge: 90 * 24 * 3600 * 1000 });
  res.redirect('/');
});

app.get('/logout', (req, res) => { res.clearCookie('access'); res.redirect('/'); });

app.get('/join', (req, res) => {
  res.render('join', {
    appName: getSetting('app_name', 'Alpha Trader'),
    fee: getSetting('fee_amount', '50'),
    currency: getSetting('fee_currency', 'USDT'),
    usdt: getSetting('usdt_address'), easypaisa: getSetting('easypaisa'),
    jazzcash: getSetting('jazzcash'), bank: getSetting('bank_details'),
    whatsapp: getSetting('whatsapp'),
    done: req.query.done === '1',
  });
});

app.post('/join', (req, res) => {
  const name = esc(req.body.name).trim();
  const contact = esc(req.body.contact).trim();
  if (!name || !contact) return res.redirect('/join');
  db.prepare('INSERT INTO payment_requests (name, contact, reference, status, created_at) VALUES (?,?,?,?,?)')
    .run(name, contact, esc(req.body.reference).trim(), 'pending', now());
  res.redirect('/join?done=1');
});

// ---------------- admin auth ----------------
app.get('/admin/login', (req, res) => {
  res.render('admin-login', { appName: getSetting('app_name', 'Alpha Trader'), error: null });
});

app.post('/admin/login', (req, res) => {
  if (!verifyPassword(esc(req.body.password), getSetting('admin_pass'))) {
    return res.render('admin-login', { appName: getSetting('app_name', 'Alpha Trader'), error: 'Ghalat password.' });
  }
  res.cookie('admin', '1', { signed: true, httpOnly: true, maxAge: 12 * 3600 * 1000 });
  res.redirect('/admin');
});

app.get('/admin/logout', (req, res) => { res.clearCookie('admin'); res.redirect('/'); });

// ---------------- admin: dashboard ----------------
app.get('/admin', requireAdmin, (req, res) => {
  const signals = db.prepare('SELECT * FROM signals ORDER BY created_at DESC LIMIT 50').all();
  const pending = db.prepare("SELECT COUNT(*) AS c FROM payment_requests WHERE status='pending'").get().c;
  const codes = db.prepare('SELECT COUNT(*) AS c FROM access_codes WHERE revoked=0').get().c;
  res.render('admin-dashboard', { appName: getSetting('app_name', 'Alpha Trader'), signals, pending, codes });
});

// ---------------- admin: signals ----------------
app.get('/admin/signals/new', requireAdmin, (req, res) => {
  res.render('admin-signal-form', { appName: getSetting('app_name', 'Alpha Trader'), s: null });
});

app.post('/admin/signals', requireAdmin, (req, res) => {
  const b = req.body;
  const market = MARKETS.includes(b.market) ? b.market : 'crypto';
  const direction = b.direction === 'short' ? 'short' : 'long';
  db.prepare(`INSERT INTO signals (market,symbol,direction,entry,stop_loss,tp1,tp2,tp3,timeframe,notes,status,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    market, esc(b.symbol).trim().toUpperCase(), direction, esc(b.entry).trim(),
    esc(b.stop_loss).trim(), esc(b.tp1).trim(), esc(b.tp2).trim(), esc(b.tp3).trim(),
    esc(b.timeframe).trim(), esc(b.notes).trim(), 'active', now(), now());
  res.redirect('/admin');
});

app.get('/admin/signals/:id/edit', requireAdmin, (req, res) => {
  const s = db.prepare('SELECT * FROM signals WHERE id=?').get(req.params.id);
  if (!s) return res.redirect('/admin');
  res.render('admin-signal-form', { appName: getSetting('app_name', 'Alpha Trader'), s });
});

app.post('/admin/signals/:id', requireAdmin, (req, res) => {
  const b = req.body;
  const market = MARKETS.includes(b.market) ? b.market : 'crypto';
  const direction = b.direction === 'short' ? 'short' : 'long';
  db.prepare(`UPDATE signals SET market=?,symbol=?,direction=?,entry=?,stop_loss=?,tp1=?,tp2=?,tp3=?,timeframe=?,notes=?,updated_at=? WHERE id=?`)
    .run(market, esc(b.symbol).trim().toUpperCase(), direction, esc(b.entry).trim(),
      esc(b.stop_loss).trim(), esc(b.tp1).trim(), esc(b.tp2).trim(), esc(b.tp3).trim(),
      esc(b.timeframe).trim(), esc(b.notes).trim(), now(), req.params.id);
  res.redirect('/admin');
});

app.post('/admin/signals/:id/status', requireAdmin, (req, res) => {
  const st = Object.keys(STATUS_LABELS).includes(req.body.status) ? req.body.status : 'active';
  db.prepare('UPDATE signals SET status=?, updated_at=? WHERE id=?').run(st, now(), req.params.id);
  res.redirect('/admin');
});

app.post('/admin/signals/:id/delete', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM signals WHERE id=?').run(req.params.id);
  res.redirect('/admin');
});

// ---------------- admin: updates ----------------
app.get('/admin/updates', requireAdmin, (req, res) => {
  const updates = db.prepare('SELECT * FROM updates ORDER BY created_at DESC').all();
  res.render('admin-updates', { appName: getSetting('app_name', 'Alpha Trader'), updates });
});

app.post('/admin/updates', requireAdmin, (req, res) => {
  const title = esc(req.body.title).trim();
  if (title) db.prepare('INSERT INTO updates (title,body,created_at) VALUES (?,?,?)').run(title, esc(req.body.body).trim(), now());
  res.redirect('/admin/updates');
});

app.post('/admin/updates/:id/delete', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM updates WHERE id=?').run(req.params.id);
  res.redirect('/admin/updates');
});

// ---------------- admin: access codes ----------------
app.get('/admin/codes', requireAdmin, (req, res) => {
  const codes = db.prepare('SELECT * FROM access_codes ORDER BY created_at DESC').all();
  res.render('admin-codes', { appName: getSetting('app_name', 'Alpha Trader'), codes, newCode: req.query.new || null });
});

app.post('/admin/codes', requireAdmin, (req, res) => {
  const days = parseInt(req.body.days || getSetting('access_days', '30'), 10) || 30;
  const code = makeCode();
  db.prepare('INSERT INTO access_codes (code,label,created_at,expires_at) VALUES (?,?,?,?)')
    .run(code, esc(req.body.label).trim(), now(), now() + days * 24 * 3600 * 1000);
  res.redirect('/admin/codes?new=' + encodeURIComponent(code));
});

app.post('/admin/codes/:id/revoke', requireAdmin, (req, res) => {
  db.prepare('UPDATE access_codes SET revoked=1 WHERE id=?').run(req.params.id);
  res.redirect('/admin/codes');
});

// ---------------- admin: payment requests ----------------
app.get('/admin/payments', requireAdmin, (req, res) => {
  const list = db.prepare(`SELECT * FROM payment_requests
    ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, created_at DESC`).all();
  res.render('admin-payments', { appName: getSetting('app_name', 'Alpha Trader'), list, newCode: req.query.new || null });
});

app.post('/admin/payments/:id/approve', requireAdmin, (req, res) => {
  const days = parseInt(getSetting('access_days', '30'), 10) || 30;
  const code = makeCode();
  const r = db.prepare('SELECT * FROM payment_requests WHERE id=?').get(req.params.id);
  db.prepare('INSERT INTO access_codes (code,label,created_at,expires_at) VALUES (?,?,?,?)')
    .run(code, r ? `Paid: ${r.name}` : 'Paid user', now(), now() + days * 24 * 3600 * 1000);
  db.prepare("UPDATE payment_requests SET status='approved', decided_at=? WHERE id=?").run(now(), req.params.id);
  res.redirect('/admin/payments?new=' + encodeURIComponent(code));
});

app.post('/admin/payments/:id/reject', requireAdmin, (req, res) => {
  db.prepare("UPDATE payment_requests SET status='rejected', decided_at=? WHERE id=?").run(now(), req.params.id);
  res.redirect('/admin/payments');
});

// ---------------- admin: settings ----------------
const SETTING_KEYS = ['app_name', 'fee_amount', 'fee_currency', 'usdt_address', 'easypaisa', 'jazzcash', 'bank_details', 'whatsapp', 'access_days'];

app.get('/admin/settings', requireAdmin, (req, res) => {
  const s = {};
  SETTING_KEYS.forEach((k) => { s[k] = getSetting(k); });
  res.render('admin-settings', { appName: getSetting('app_name', 'Alpha Trader'), s, msg: req.query.msg || null });
});

app.post('/admin/settings', requireAdmin, (req, res) => {
  SETTING_KEYS.forEach((k) => setSetting(k, esc(req.body[k])));
  if (esc(req.body.new_password).trim()) setSetting('admin_pass', hashPassword(esc(req.body.new_password).trim()));
  res.redirect('/admin/settings?msg=saved');
});

app.use((req, res) => res.status(404).send('Not found'));

app.listen(PORT, () => console.log(`Signals app running on port ${PORT}`));
