# Signals App — Deploy Guide (Render + GitHub)

Tumhari app ka poora code taiyar hai. Ye **public app** hai — log link kholenge, joining fee de kar access code lenge, aur tum **admin panel** se sab control karoge (signals post karna, codes banana, payments approve karna).

Isay internet par live karne ke liye neeche diye gaye steps follow karo. Koi step samajh na aaye to mujh se pooch lena.

---

## Step 1 — GitHub account banao (free)

1. [github.com](https://github.com) kholo → **Sign up** dabao
2. Email, password, username do → account verify kar lo

## Step 2 — Repository banao aur ye files upload karo

1. GitHub par **New repository** (plus ➕ icon → New repository)
2. Naam likho: `alpha-trader` → **Public** select karo → **Create repository**
3. Ab jo page khulega us par **"uploading an existing file"** ka link hoga — us par click karo
4. Apne computer par `alpha-trader` folder kholo, **saari files aur folders** (views, public waghera) drag kar ke GitHub par drop karo
5. Neeche **Commit changes** dabao

## Step 3 — Render account banao (free)

1. [render.com](https://render.com) kholo → **Get Started** → **GitHub se sign up** karo

## Step 4 — App deploy karo

1. Render dashboard me **New +** → **Web Service** dabao
2. Apna `alpha-trader` repository select karo → **Connect**
3. Ye settings karo:
   - **Name:** `alpha-trader` (ya jo marzi)
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Plan:** Free
4. **Environment Variables** me ye 2 add karo (Add Environment Variable):
   - `NODE_VERSION` = `22`
   - `SESSION_SECRET` = koi lamba random text khud likh do (jaise `mera-secret-8f3k9x2p7q`)
5. **Create Web Service** dabao → deploy shuru ho jayega (2-3 minute)

Deploy complete hote hi tumhe app ka **public URL** mil jayega, jaise:
`https://alpha-trader.onrender.com` — ye link sab ke liye khulega.

## Step 5 — Pehli setup (sab se zaroori)

1. Apne app ke URL ke aakhir me `/admin/login` lagao, jaise:
   `https://alpha-trader.onrender.com/admin/login`
2. Password likho: **`admin123`** → Login
3. **Settings** me ja kar foran ye karo:
   - Apna **naya admin password** set karo (purana `admin123` hatao)
   - App ka **naam** apni marzi ka rakho
   - **Joining fee** aur currency set karo
   - **Payment details** bharo: USDT address, Easypaisa / JazzCash number, bank details — jo bhi logon se lena hai
   - Apna **WhatsApp number** dalo
   - **Save** dabao

## Step 6 — Signals post karo

1. **Dashboard** → **＋ New Signal**
2. Market select karo: **Crypto / Forex / Stocks**
3. Symbol (jaise BTCUSDT, EURUSD, AAPL), Long/Short, Entry, Stop Loss, TP1/TP2/TP3, timeframe aur notes bharo → **Save**
4. **Updates** page par ja kar market updates/announcements post karo
5. Signal ka result aaye to Dashboard se us ka **Status** change kar do (TP1 Hit, SL Hit waghera)

## Step 7 — Subscriber ka flow (ye sab automatic hai)

1. Subscriber `/join` page par fee aur tumhari payment details dekhta hai
2. Wo payment kar ke **"I've Paid"** form bharta hai (naam, WhatsApp, payment reference)
3. Tum **Payments** page par us ki request dekh kar **Approve** dabate ho → ek **access code** ban jata hai
4. Wo code subscriber ko **WhatsApp** par bhej do
5. Subscriber `/unlock` par code daalta hai → usay **Crypto, Forex, Stocks, Updates** — chaaron sections khul jate hain

---

## ⚠️ Zaroori notes (pehle se maloom hona chahiye)

- **Free plan "so jata hai":** agar 15 minute koi app na khole to server sleep ho jata hai. Pehla visitor 30-60 second wait karega, phir sab normal. Ye free hosting ki limit hai, koi kharabi nahi.
- **Database reset ka khatra:** free plan par jab app dobara deploy ho to purana data (signals/codes) reset ho sakta hai. Is liye ahem signals ka record apne paas alag se bhi rakho (screenshot ya diary). Jab app se earning shuru ho jaye to paid plan ya alag database lagana behtar hoga — us waqt mujh se kehna, main bata dunga.
- **SESSION_SECRET** aur admin password kabhi kisi ko mat do.
- Phone par app ka URL khol kar browser ke menu se **"Add to Home Screen"** kar lo — app jaisa icon ban jayega.

## Kuch change karwana ho to

Naam, rang, fee ka tareeqa, ya koi naya feature (jaise signal ki expiry, Telegram alerts) — bas mujhe bata do, main code update kar dunga. Phir GitHub par files dobara upload karne se Render khud hi app update kar dega.
